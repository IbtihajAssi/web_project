-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2023 at 08:15 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user-db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `price`, `image`, `quantity`) VALUES
(30, 1, 'Beko Espresso Coffee Machine 1350W', '2000', 'cof4.jpg', 1),
(31, 1, 'Midea RAC Split Inverter 2 Ton 18,000 BTU', '4000', 'cond3.jpg', 1),
(32, 1, 'BlueStar USB Fan 4W Wooden.', '70', 'fan3.jpg', 1),
(33, 1, 'Star Fan 2 in One, 120W, 18 Inch, Black Color.', '300', 'fan1.jpg', 1),
(35, 1, 'Hemilton Cooler Fan 16 inch, Black Color.', '100', 'fan4.jpg', 1),
(36, 1, 'Beko Espresso Coffee Machine 1200W', '500', 'cof2.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `conditioning`
--

CREATE TABLE `conditioning` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `conditioning`
--

INSERT INTO `conditioning` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(1, 'Midea RAC Split Inverter 1 Ton 12,000 BTU, Wi-Fi Control, White Color.', '3000', 'cond1.jpg', '100'),
(2, 'Midea RAC Split Inverter 1 Ton 12,000 BTU, Wi-Fi Control, White Color.', '3500', 'cond2.jpg', '100'),
(3, 'Midea RAC Split Inverter 2 Ton 18,000 BTU, Wi-Fi Control, White Color.', '4000', 'cond3.jpg', '100'),
(4, 'Midea RAC Split Inverter 1.5 Ton 18,000 BTU, Wi-Fi Control, White Color.', '5000', 'cond4.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `cooffe`
--

CREATE TABLE `cooffe` (
  `quantity` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantitty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cooffe`
--

INSERT INTO `cooffe` (`quantity`, `name`, `price`, `image`, `quantitty`) VALUES
(1, 'Beko Arabic Coffee Machine 1100W, Prepare Up to 6 Cups, Black/Rose Gold Color.', '950', 'cof1.jpg', '100'),
(2, 'Beko Espresso Coffee Machine 1200W, Stainless Steel, Black Color.', '500', 'cof2.jpg', '100'),
(3, 'Beko Espresso Coffee Machine 1350W, Stainless Steel, Black Color.', '2000', 'cof4.jpg', '100'),
(4, 'Korkmaz Turkish Coffee Machine 400W ,Prepare up to 4 Cups, Red/Chrome Color.', '270', 'cof5.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `dishwasher`
--

CREATE TABLE `dishwasher` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dishwasher`
--

INSERT INTO `dishwasher` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(7, 'Beko Dishwasher 5 Programs, 13 Place Setting, 2 Racks, White Color', '1700', 'dish1.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `dryer`
--

CREATE TABLE `dryer` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dryer`
--

INSERT INTO `dryer` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(1, 'Beko Dryer 8Kg, Heat Pump System Save Energy, 15 Programs, Dark Stainless.', '3000', 'dry1.jpg', '100'),
(2, 'Beko Dryer 9Kg, Condenser System, 15 Programs, Dark Stainless.', '3000', 'dry2.jpg', '100'),
(3, 'EVA Dryer 10Kg, Heat Pump System Save Energy, 15 Programs, Dark Grey.', '3300', 'dry3.jpg', '100'),
(4, 'EVA Dryer 8Kg, Condenser System, 15 Programs, Dark Grey.', '2500', 'dry4.jpg', '100'),
(5, 'LG Dryer 16Kg, Heat Pump System Save Energy, 14 Programs, Dark Stainless.', '8500', 'dry5.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `electric-kitchen`
--

CREATE TABLE `electric-kitchen` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `electric-kitchen`
--

INSERT INTO `electric-kitchen` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(1, 'Breville food processor 1000 watts, capacity 1.5 / 2.6 liters, silver color.', '1240', '11.jpg', '10'),
(2, 'Trust vegetable chopper 300 watts, 2 liter capacity, silver color.', '99', '2.jpg', '100'),
(3, 'Breville fruit and vegetable juicer 1250 watts, silver color.', '1100', '3.jpg', '100'),
(4, 'Trust juicer with slow juice technology 120 watts, <br>bowl capacity 1.2 liters, black color.', '249', '4.jpg', '100'),
(5, 'Trust Electric Citrus Juicer 40W, 1.2L Bowl, Stainless Steel.', '99', '5.jpg', '100'),
(6, 'Breville fruit and vegetable juicer 1300 watts, silver color.', '1090', '6.jpg', '100'),
(7, 'LG Microwave 25 Liter Capacity, 1150 Watt, Smart Inverter Technology, Even Heating and Easy Cleaning, Black.', '950', '7.jpg', '100'),
(8, 'LG Microwave with Grill, 42 Liter Capacity, 1100 Watt', '1200', '8.jpg', '100'),
(9, ' Built-in Microwave Sauter, 34 L, 1500 W, 2 in 1, 10 Programs, Silver', '1490', '9.jpg', '100'),
(10, 'Korkmaz Toaster Pressure 1800W, Multi-Cooking, Vanilla Color.', '429', '10.jpg', '100'),
(11, 'Breville toaster pressure 2200 watts, silver color.', '629', '11.jpg', '100'),
(12, 'Trust hand mixer 100 watts, 5 speeds, white.', '49', '12.jpg', '100'),
(13, 'Stand mixer 2000 watts, with a bowl capacity of 12 liters, silver color.', '799', '18.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `fan`
--

CREATE TABLE `fan` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `floor-care`
--

CREATE TABLE `floor-care` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `haircare`
--

CREATE TABLE `haircare` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `heater`
--

CREATE TABLE `heater` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hob`
--

CREATE TABLE `hob` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hood`
--

CREATE TABLE `hood` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `laser`
--

CREATE TABLE `laser` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `men`
--

CREATE TABLE `men` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `method` varchar(100) NOT NULL,
  `flat` varchar(100) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `total_products` varchar(255) NOT NULL,
  `total_price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oven`
--

CREATE TABLE `oven` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `oven`
--

INSERT INTO `oven` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(2, 'Amica Built-In Electric Oven 60 Cm, 65 Liter Capacity, 12 Programs, 3100 Watts, Stainless', '3400', 'ov1.jpg', '100'),
(3, 'Amica Built-In Electric Oven 60 Cm, 65 Liter Capacity, 12 Programs, 3100 Watts, Stainless', '3000', 'ov2.jpg', '100'),
(4, 'Beko Built-In Electric Oven, 60 Cm, 72 Liter Capacity, 13 Programs, 3400 Watts, Black.', '3000', 'ov3.jpg', '100'),
(5, 'Beko Built-In Electric Oven, 60 Cm, 72 Liter Capacity, 9 Programs, 2800 Watts, Black', '2500', 'ov4.jpg', '100'),
(6, 'EVA Built-in Electric Oven, 60 cm, 65 Liter Capacity, 10 Programs, 2600 Watts, Stainless', '1500', 'ov5.jpg', '100'),
(7, 'Firegas Built-in Electric Oven, 60 Cm, 65 Liter Capacity, 10 Programs, 3100 Watts, Stainless', '2300', 'ov6.jpg', '100'),
(8, 'Firegas Built-in Electric Oven, 60 Cm, 65 Liter Capacity, 10 Programs, Stainless Steel.', '2000', 'ov7.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(9, 'Beko Refrigerator 4 Door Capacity 580 Ltr, Inverter Compressor Save Energy, Black', '8500', 'ref1.jpg', '100'),
(10, 'Beko Refrigerator 4 Door Capacity 580 Ltr, Inverter Compressor Save Energy, White.', '800', 'ref2.png', '100'),
(11, 'Beko Refrigerator 4 Door Capacity 624 Ltr, Inverter Compressor Save Energy, ​Silver', '7700', 'ref3.jpg', '100'),
(12, 'Beko Refrigerator 4 Door Capacity 626 Ltr, Inverter Compressor Save Energy, Silver', '6800', 'ref4.jpg', '100'),
(13, 'EVA Refrigerator 4 Door Capacity 509 Ltr, Inverter Compressor Save Energy, Black', '5500', 'ref5.jpg', '100'),
(14, 'FG Refrigerator Built-in Bottom Mount Capacity 247 Ltr, Right Hand Opening, White Color.', '6500', 'ref9.jpg', '100'),
(15, 'EVA Refrigerator Bottom Mount Capacity 553 Ltr, Stainless Steel.', '4400', 'ref7.jpg', '100'),
(16, 'EVA Refrigerator Bottom Mount Capacity 582 Ltr, Dual Cooling, Black Stainless.', '5500', 'ref8.jpg', '100');

-- --------------------------------------------------------

--
-- Table structure for table `refrigeter`
--

CREATE TABLE `refrigeter` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stream`
--

CREATE TABLE `stream` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tv`
--

CREATE TABLE `tv` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'ibtihaj', 'ibtihajaassi@gmail.com', '25f9e794323b453885f5181f1b624d0b', 'user'),
(2, 'jeje', 's12029066@stu.najah.edu', '01e5297879c48b8dfe306e35970cfc86', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `washer`
--

CREATE TABLE `washer` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conditioning`
--
ALTER TABLE `conditioning`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cooffe`
--
ALTER TABLE `cooffe`
  ADD PRIMARY KEY (`quantity`);

--
-- Indexes for table `dishwasher`
--
ALTER TABLE `dishwasher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dryer`
--
ALTER TABLE `dryer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `electric-kitchen`
--
ALTER TABLE `electric-kitchen`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fan`
--
ALTER TABLE `fan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `floor-care`
--
ALTER TABLE `floor-care`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haircare`
--
ALTER TABLE `haircare`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `heater`
--
ALTER TABLE `heater`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hob`
--
ALTER TABLE `hob`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hood`
--
ALTER TABLE `hood`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `laser`
--
ALTER TABLE `laser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `men`
--
ALTER TABLE `men`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oven`
--
ALTER TABLE `oven`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tv`
--
ALTER TABLE `tv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `washer`
--
ALTER TABLE `washer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `conditioning`
--
ALTER TABLE `conditioning`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cooffe`
--
ALTER TABLE `cooffe`
  MODIFY `quantity` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dishwasher`
--
ALTER TABLE `dishwasher`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dryer`
--
ALTER TABLE `dryer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `electric-kitchen`
--
ALTER TABLE `electric-kitchen`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `fan`
--
ALTER TABLE `fan`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `floor-care`
--
ALTER TABLE `floor-care`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `haircare`
--
ALTER TABLE `haircare`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `heater`
--
ALTER TABLE `heater`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hob`
--
ALTER TABLE `hob`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hood`
--
ALTER TABLE `hood`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `laser`
--
ALTER TABLE `laser`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `men`
--
ALTER TABLE `men`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oven`
--
ALTER TABLE `oven`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tv`
--
ALTER TABLE `tv`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `washer`
--
ALTER TABLE `washer`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
